import fp from 'fastify-plugin'
import jwt from 'jsonwebtoken'
export type Claims = { sub: string; role: string; familyId: string }
declare module 'fastify' { interface FastifyRequest { claims?: Claims } }

export const authPlugin = fp(async (app) => {
  app.decorateRequest('claims', null)
  app.addHook('preHandler', async (req, _res) => {
    if ((req.routerPath || '').includes('/auth/')) return
    const header = req.headers.authorization || ''
    const token = header.replace('Bearer ', '')
    if (!token) throw app.httpErrors.unauthorized()
    const claims = jwt.verify(token, process.env.JWT_SECRET!) as Claims
    req.claims = claims
    req.headers['x-cb-family'] = claims.familyId
  })
})
