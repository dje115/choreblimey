import Fastify from 'fastify'
import cors from '@fastify/cors'
import multipart from '@fastify/multipart'
import { routes } from './routes/index.js'
import { authPlugin } from './utils/auth.js'

const app = Fastify({ logger: true })
await app.register(cors, { origin: true, credentials: true })
await app.register(multipart)
await app.register(authPlugin)
await app.register(routes, { prefix: '/v1' })

app.listen({ port: 1501, host: '0.0.0.0' }).then(() => {
  console.log('API on http://localhost:1501')
})
