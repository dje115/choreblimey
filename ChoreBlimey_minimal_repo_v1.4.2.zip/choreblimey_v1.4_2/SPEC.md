# Place your ChoreBlimey_SPEC_v1.4.1_FULL.md here for Cursor/Codex to read.
